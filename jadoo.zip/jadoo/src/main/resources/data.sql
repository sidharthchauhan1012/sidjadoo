insert into students
values(1,'sid','sid@gmail.com');

insert into students
values(2,'Gaurav','goru@gmail.com');

insert into students
values(3,'rajitha','rajo@gmail.com');

insert into students
values(4,'varun','varu@gmail.com');


insert into students
values(5,'nikita','lalbaal@gmail.com');

insert into students
values(6,'megha','mera@gmail.com');