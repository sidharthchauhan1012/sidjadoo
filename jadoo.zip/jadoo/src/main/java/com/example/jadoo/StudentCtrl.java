package com.example.jadoo;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.jadoo.pojo.Student;
import com.example.jadoo.pojo.StudentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
@Api(tags="Student")
@RestController
@RequestMapping("r1")
public class StudentCtrl {

	@Autowired
	StudentService studentService;
	@ApiOperation(value="Get All Students Records",notes="Get api to fetch all student objects")
	@RequestMapping(value="", method=RequestMethod.GET)
	public List<Student> students(){
		
		return studentService.getAllStudent();
	}
	
	@ApiOperation(value="Add new Student",notes="Post api to add new Student")
	@RequestMapping(value="", method=RequestMethod.POST)
	@ResponseStatus(value=HttpStatus.CREATED)
	public void addStudent(@RequestBody Student std,HttpServletRequest request,HttpServletResponse response){
		
		Student student=studentService.addStudent(std);
		response.setHeader("Location", request.getRequestURL().append("/").append(student.getId()).toString());
		
	}
	
	  @ApiOperation(value="Get Particular Student Record",notes="Get api to fetch particular Student")
	  @RequestMapping(value="/{id}", method= RequestMethod.GET) public
	  Optional<Student> getStudent(@PathVariable("id") int id) { return
	  this.studentService.getStudentById(id); }
	 
	  
	  @ApiOperation(value="Update Student Details",notes="PUT api to update the existing Student")
	  @RequestMapping(value="/{id}", method= RequestMethod.PUT) public Student
	  updateStudent(@PathVariable("id") int id, @RequestBody Student std) 
	  { 
		  return this.studentService.update(std);
	  }
	  
	  @ApiOperation(value="Delete Student",notes="DELETE api to delete Student details")
	  @RequestMapping(value="/{id}", method= RequestMethod.DELETE) public
	  void deleteStudent(@PathVariable("id") int id)
	  { 
	  this.studentService.deleteStd(id);
	  }
	 
}
