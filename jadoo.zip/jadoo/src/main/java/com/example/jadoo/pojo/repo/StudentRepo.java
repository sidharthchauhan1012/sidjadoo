package com.example.jadoo.pojo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.jadoo.pojo.Student;

public interface StudentRepo extends CrudRepository<Student, Integer>{

	

	
}
