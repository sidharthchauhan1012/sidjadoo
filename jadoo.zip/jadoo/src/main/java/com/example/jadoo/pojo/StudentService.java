package com.example.jadoo.pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jadoo.pojo.repo.StudentRepo;

@Service
public class StudentService<T> {

	@Autowired
	StudentRepo studentrepo;
	
	public List<Student> getAllStudent(){
		List<Student> allStudent=new ArrayList<Student>();
		studentrepo.findAll().forEach(s -> allStudent.add(s) );
		return allStudent;
	}
	
	public Student addStudent(Student std) {
		return studentrepo.save(std);
		
	}
	
	public Optional<Student> getStudentById(int id)
	{
		return studentrepo.findById(id);
	}
	
	
	public <std extends Student> Student update(Student std) {
		// TODO Auto-generated method stub
		return studentrepo.save(std);
	}
	
	public void deleteStd(int id)
	{
		studentrepo.deleteById(id);
	}

	  
	 
}

